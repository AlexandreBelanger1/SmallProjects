#include <xc.h>

#include "SpecialState.h"

void do_something(void)
{
    return;
}