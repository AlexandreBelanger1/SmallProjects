// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef Special
#define	Special
#include "xc.h"
 // include processor files - each processor file is guarded.  

void do_something (void);



#endif	/* Special */